package kr.co.sist.lunch.user.run;

public class LunchClientRun {
	public static void main(String[] args) {

	}// main
}// class
