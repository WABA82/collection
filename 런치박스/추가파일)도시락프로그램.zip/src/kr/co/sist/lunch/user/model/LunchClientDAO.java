package kr.co.sist.lunch.user.model;

public class LunchClientDAO {

}
