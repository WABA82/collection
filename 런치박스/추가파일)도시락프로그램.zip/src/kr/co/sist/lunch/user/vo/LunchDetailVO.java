package kr.co.sist.lunch.user.vo;

public class LunchDetailVO {

}
