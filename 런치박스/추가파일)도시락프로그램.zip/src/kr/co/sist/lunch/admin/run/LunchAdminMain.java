package kr.co.sist.lunch.admin.run;

import kr.co.sist.lunch.admin.view.LunchLoginView;

public class LunchAdminMain {

	public static void main(String[] args) {
		new LunchLoginView();
	}// main

}// class
