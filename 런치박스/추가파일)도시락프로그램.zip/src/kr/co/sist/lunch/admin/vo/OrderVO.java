package kr.co.sist.lunch.admin.vo;

public class OrderVO {

	private String orderNum, lunchCode, lunchName, orderName, orderDate, phone, ipAddress, status;
	private int quan, price;

	public OrderVO(String orderNum, String lunchCode, String lunchName, String orderName, String orderDate,
			String phone, String ipAddress, String status, int quan, int price) {
		this.orderNum = orderNum;
		this.lunchCode = lunchCode;
		this.lunchName = lunchName;
		this.orderName = orderName;
		this.orderDate = orderDate;
		this.phone = phone;
		this.ipAddress = ipAddress;
		this.status = status;
		this.quan = quan;
		this.price = price;
	}

	public String getOrderNum() {
		return orderNum;
	}

	public String getLunchCode() {
		return lunchCode;
	}

	public String getLunchName() {
		return lunchName;
	}

	public String getOrderName() {
		return orderName;
	}

	public String getOrderDate() {
		return orderDate;
	}// getOrderDate

	public String getPhone() {
		return phone;
	}// getPhone

	public String getIpAddress() {
		return ipAddress;
	}// getIpAddress

	public String getStatus() {
		return status;
	}// getStatus

	public int getQuan() {
		return quan;
	}// getQuan

	public int getPrice() {
		return price;
	}// getPrice

	@Override
	public String toString() {
		return "OrderVO [orderNum=" + orderNum + ", lunchCode=" + lunchCode + ", lunchName=" + lunchName
				+ ", orderName=" + orderName + ", orderDate=" + orderDate + ", phone=" + phone + ", ipAddress="
				+ ipAddress + ", status=" + status + ", quan=" + quan + ", price=" + price + "]";
	}// toString

}// class
