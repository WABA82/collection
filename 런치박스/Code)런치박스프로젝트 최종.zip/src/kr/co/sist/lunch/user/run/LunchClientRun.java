package kr.co.sist.lunch.user.run;

import kr.co.sist.lunch.user.view.LunchClientView;

public class LunchClientRun {

	public static void main(String[] args) {
		new LunchClientView();
	}//main

}//class
